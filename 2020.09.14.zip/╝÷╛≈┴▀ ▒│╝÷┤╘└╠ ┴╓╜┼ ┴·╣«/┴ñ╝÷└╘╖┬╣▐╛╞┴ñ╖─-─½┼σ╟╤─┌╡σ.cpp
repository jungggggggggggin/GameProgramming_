#include <stdio.h>


int main()
{
	int num = 5;
	int a[num] = {1,10,15,2,4};
	
	for(int i=0; i<num; i++){
		int temp;
		for (int j =0; j<num-1; j++)
		{
			if(a[j]  >  a[j+1])
			{
				temp =a[j];
				a[j] = a[j+1];
				a[j+1] = temp;
			}
		}
		printf("%d",a[i])
	}
	return 0;
} 
